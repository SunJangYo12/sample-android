(jarsigner -verbose -keystore release-key.keystore -certs bin/alienbloodbath-unsigned.apk release-key &&
 mv bin/alienbloodbath-unsigned.apk bin/alienbloodbath-release.apk)

