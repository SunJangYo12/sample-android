/** Automatically generated file. DO NOT MODIFY */
package info.dreamingfish123.wavetransdemo;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}