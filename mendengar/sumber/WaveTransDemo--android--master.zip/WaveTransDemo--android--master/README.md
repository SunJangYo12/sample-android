#Wave Transfer Demo (android)
在android系统上实现的通过音频接口传输数据的演示程序.

##~~依赖~~
- ~~[Wave Transfer Protocol](https://github.com/abysshal/WaveTransProto "a related project")~~